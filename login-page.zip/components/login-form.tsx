"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle login logic here
    console.log("Login attempt with:", { email, password })
  }

  return (
    <div className="bg-white p-5 w-[330px] rounded-[20px] shadow-[7px_7px_7px_rgba(44,44,44,0.514)]">
      <header className="text-emerald-700 text-2xl mb-2 ml-5 tracking-tighter">
        <h1 className="text-[25px] font-bold">Login</h1>
      </header>

      <div className="w-[42%] ml-6 mb-12 h-0.5 bg-emerald-200/80"></div>

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <Input
            type="email"
            id="email"
            name="email"
            placeholder="E-mail"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="border-0 border-b-2 border-gray-300 bg-transparent outline-none px-1 py-2 text-lg text-gray-800/90 w-[92%] mb-4 ml-3 focus:border-emerald-500 placeholder:text-gray-500/70 placeholder:font-bold placeholder:text-base"
          />

          <Input
            type="password"
            id="password"
            name="password"
            placeholder="Senha"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="border-0 border-b-2 border-gray-300 bg-transparent outline-none px-1 py-2 text-lg text-gray-800/90 w-[92%] mb-4 ml-3 focus:border-emerald-500 placeholder:text-gray-500/70 placeholder:font-bold placeholder:text-base"
          />
        </div>

        <Button
          type="submit"
          className="ml-5 text-center cursor-pointer bg-emerald-600 text-white font-semibold tracking-tighter text-[19px] leading-8 rounded-[10px] h-10 w-[85%] mt-6 transition-transform duration-400 hover:scale-105"
        >
          Acessar
        </Button>

        <div className="mt-12 ml-1 text-sm">
          <a href="/subscription" className="font-bold text-gray-500/70 hover:text-emerald-700 hover:underline">
            Já é assinante e não tem login?
          </a>
        </div>

        <div className="mt-4 ml-2 text-sm">
          <a href="/recoverpass" className="font-bold text-gray-500/70 hover:text-emerald-700 hover:underline">
            Esqueceu a senha?
          </a>
        </div>
      </form>
    </div>
  )
}

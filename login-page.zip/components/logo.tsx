export default function Logo() {
  return (
    <div className="transition-transform duration-300 ease-in-out hover:scale-[1.07] w-[230px] z-10 mx-auto -mb-3">
      <img
        src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Di%C3%A1rio_do_Nordeste_logo.svg/2560px-Di%C3%A1rio_do_Nordeste_logo.svg.png"
        alt="Diário do Nordeste Logo"
        className="w-[250px]"
      />
    </div>
  )
}

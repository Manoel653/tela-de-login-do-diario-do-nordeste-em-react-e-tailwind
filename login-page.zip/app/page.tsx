import LoginForm from "@/components/login-form"
import Logo from "@/components/logo"

export default function LoginPage() {
  return (
    <main
      className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden bg-cover bg-top bg-no-repeat animate-fadeIn"
      style={{
        backgroundImage:
          "url('https://img.freepik.com/vetores-premium/ilustracao-vetorial-de-fundo-com-conceito-de-ondas-do-mar_1025151-101.jpg?w=996')",
      }}
    >
      <header className="w-full absolute top-0 flex justify-center py-6 px-4 bg-emerald-200/50 hover:bg-emerald-200 transition-all duration-300 ease-in-out transform hover:translate-y-0 -translate-y-2.5">
        <Logo />
      </header>

      <div className="mt-32 mb-8">
        <LoginForm />
      </div>
    </main>
  )
}
